@extends('layouts.app')
@section('title', 'Input Nilai Matrix')
@section('header', 'Input Nilai — ' . $assessment->title)

@section('content')
<div class="space-y-5 max-w-3xl mx-auto">

    {{-- Panduan --}}
    <div class="bg-blue-50 border border-blue-200 rounded-xl px-5 py-4">
        <h3 class="font-semibold text-blue-800 text-sm mb-2">Panduan Penilaian</h3>
        <div class="grid sm:grid-cols-2 gap-3 mb-3">
            <div class="bg-blue-100 rounded-lg px-3 py-2">
                <p class="text-xs font-bold text-blue-700 mb-1">🔵 BENEFIT</p>
                <p class="text-xs text-blue-700">
                    Nilai <strong>semakin tinggi = semakin baik</strong>.<br>
                    Contoh: Efektivitas tinggi → nilai 10
                </p>
            </div>
            <div class="bg-orange-50 rounded-lg px-3 py-2 border border-orange-200">
                <p class="text-xs font-bold text-orange-600 mb-1">🟠 COST</p>
                <p class="text-xs text-orange-700">
                    Nilai <strong>semakin tinggi = semakin buruk</strong>.<br>
                    Contoh: Biaya mahal → nilai 10 (= sangat buruk)
                </p>
            </div>
        </div>
        <p class="text-xs text-blue-600">
            Input: <strong>1–10</strong> →
            Sistem konversi ke <strong>0.1–1.0</strong> untuk kalkulasi EDAS.
        </p>
    </div>

    @if($alternatives->isEmpty())
        <div class="bg-white rounded-xl border border-gray-200 px-6 py-12 text-center">
            <p class="text-gray-500 text-sm">Belum ada alternatif.</p>
            <a href="{{ route('assessments.edit', $assessment) }}"
               class="mt-2 inline-block text-blue-600 hover:underline text-sm">Edit assessment →</a>
        </div>
    @else

        {{-- Navigasi wizard --}}
        <div class="bg-white rounded-xl border border-gray-200 px-5 py-4">

            {{-- Progress bar + label --}}
            <div class="mb-3">
                <div class="flex items-center justify-between mb-1.5">
                    <span class="text-xs text-gray-500">
                        Alternatif <strong id="current-label">1</strong> dari <strong>{{ $alternatives->count() }}</strong>
                    </span>
                    <span class="text-xs text-gray-400" id="step-filled-label">0/{{ $criteria->count() }} kriteria diisi</span>
                </div>
                {{-- Track dots --}}
                <div class="flex gap-1.5 items-center mb-2">
                    @foreach($alternatives as $i => $alt)
                        <div id="dot-{{ $i }}"
                             class="h-2 rounded-full transition-all duration-300 {{ $i === 0 ? 'bg-blue-600 flex-[2]' : 'bg-gray-200 flex-1' }}">
                        </div>
                    @endforeach
                </div>
                {{-- Progress bar pengisian --}}
                <div class="w-full bg-gray-100 rounded-full h-1.5">
                    <div id="fill-bar" class="h-1.5 rounded-full bg-green-500 transition-all duration-300" style="width: 0%"></div>
                </div>
            </div>

            {{-- Nama alternatif aktif --}}
            @foreach($alternatives as $i => $alt)
                <div id="alt-name-{{ $i }}" class="{{ $i !== 0 ? 'hidden' : '' }}">
                    <h3 class="font-bold text-gray-900 text-base">{{ $alt->name }}</h3>
                    @if($alt->description)
                        <p class="text-xs text-gray-400 mt-0.5">{{ Str::limit($alt->description, 100) }}</p>
                    @endif
                </div>
            @endforeach

            {{-- Navigasi prev/next --}}
            <div class="flex items-center justify-between mt-4">
                <button type="button" id="btn-prev" onclick="navigate(-1)"
                        class="flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-200
                               text-sm font-medium text-gray-600 hover:bg-gray-50 transition
                               disabled:opacity-40 disabled:cursor-not-allowed" disabled>
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                    </svg>
                    Sebelumnya
                </button>

                <span class="text-sm text-gray-400">
                    <span id="current-num">1</span> / {{ $alternatives->count() }}
                </span>

                <button type="button" id="btn-next" onclick="navigate(1)"
                        class="flex items-center gap-2 px-4 py-2 rounded-lg border border-blue-600
                               bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 transition">
                    Selanjutnya
                    <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                    </svg>
                </button>
            </div>
        </div>

        {{-- Form --}}
        <form method="POST" action="{{ route('assessments.values.store', $assessment) }}" id="form-nilai">
            @csrf

            {{-- Satu card per alternatif --}}
            @foreach($alternatives as $i => $alt)
                <div id="step-{{ $i }}" class="{{ $i !== 0 ? 'hidden' : '' }} space-y-0 bg-white rounded-xl border border-gray-200 overflow-hidden">

                    <div class="divide-y divide-gray-100">
                        @foreach($criteria as $c)
                            @php
                                $savedDecimal = $valueMap[$alt->id][$c->id] ?? null;
                                $savedSlider  = $savedDecimal !== null
                                    ? (int) round($savedDecimal * 10)
                                    : null;
                            @endphp

                            <div class="px-5 py-4">
                                {{-- Baris atas: badge + nama + display nilai --}}
                                <div class="flex items-center justify-between gap-4 mb-3">
                                    <div class="flex items-center gap-2 min-w-0">
                                        <span class="shrink-0 text-xs font-bold px-1.5 py-0.5 rounded
                                            {{ $c->isBenefit() ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-600' }}">
                                            {{ strtoupper($c->type) }}
                                        </span>
                                        <span class="text-sm font-medium text-gray-800 truncate">{{ $c->name }}</span>
                                        <span class="shrink-0 text-xs text-gray-400">{{ $c->weight_percent }}</span>
                                    </div>

                                    <div class="text-right shrink-0">
                                        <span class="text-xl font-bold text-gray-900"
                                              id="display-{{ $alt->id }}-{{ $c->id }}">
                                            {{ $savedSlider ?? '—' }}
                                        </span>
                                        <span class="text-xs text-gray-400">/10</span>
                                        <div class="text-xs text-gray-400 mt-0.5">
                                            = <span id="decimal-{{ $alt->id }}-{{ $c->id }}">
                                                {{ $savedSlider !== null ? number_format($savedSlider / 10, 1) : '—' }}
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                {{-- Slider --}}
                                <div class="flex items-center gap-3">
                                    <span class="text-xs text-gray-400 w-3 shrink-0 text-center">1</span>
                                    <input type="range"
                                           min="1" max="10" step="1"
                                           value="{{ $savedSlider ?? 1 }}"
                                           data-alt="{{ $alt->id }}"
                                           data-crit="{{ $c->id }}"
                                           data-step="{{ $i }}"
                                           class="slider-input flex-1 h-2 rounded-full appearance-none cursor-pointer"
                                           style="accent-color: {{ $c->isBenefit() ? '#2563eb' : '#f97316' }}"
                                           oninput="onSliderChange(this)">
                                    <span class="text-xs text-gray-400 w-3 shrink-0 text-center">10</span>

                                    <input type="hidden"
                                           name="values[{{ $alt->id }}][{{ $c->id }}]"
                                           id="hidden-{{ $alt->id }}-{{ $c->id }}"
                                           value="{{ $savedDecimal ?? '' }}">
                                </div>

                                {{-- Label kontekstual --}}
                                <div class="flex justify-between text-xs text-gray-300 mt-1 px-6">
                                    @if($c->isBenefit())
                                        <span>Sangat Buruk</span><span>Sangat Baik</span>
                                    @else
                                        <span>Sangat Murah/Mudah</span><span>Sangat Mahal/Sulit</span>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            @endforeach

            {{-- Footer: total + tombol simpan --}}
            <div class="mt-4 bg-white rounded-xl border border-gray-200 px-6 py-4 flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <a href="{{ route('assessments.show', $assessment) }}"
                       class="text-sm text-gray-500 hover:text-gray-700">← Kembali</a>
                    <span class="text-xs text-gray-400">
                        Total: <strong id="total-filled">0</strong>/{{ $alternatives->count() * $criteria->count() }} sel diisi
                    </span>
                </div>
                <button type="submit" id="btn-simpan"
                        class="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed
                               text-white px-5 py-2.5 rounded-lg text-sm font-medium transition">
                    Simpan Semua Nilai
                </button>
            </div>
        </form>

    @endif
</div>

@push('scripts')
<script>
    const TOTAL_STEPS = {{ $alternatives->count() }};
    const TOTAL_CRIT  = {{ $criteria->count() }};
    const TOTAL_SLOTS = TOTAL_STEPS * TOTAL_CRIT;

    let currentStep = 0;

    // filledMap[altId] = Set of critIds yang sudah diisi
    const filledMap = {};

    // Inisialisasi dari nilai tersimpan di DB
    @foreach($alternatives as $alt)
        filledMap[{{ $alt->id }}] = new Set();
        @foreach($criteria as $c)
            @if(isset($valueMap[$alt->id][$c->id]))
                filledMap[{{ $alt->id }}].add({{ $c->id }});
            @endif
        @endforeach
    @endforeach

    // Data alternatif untuk keperluan JS
    const altIds = [
        @foreach($alternatives as $alt)
            {{ $alt->id }},
        @endforeach
    ];

    // ── Navigasi antar step ───────────────────────────────────────────────────

    function navigate(direction) {
        const next = currentStep + direction;
        if (next < 0 || next >= TOTAL_STEPS) return;

        // Sembunyikan step lama
        document.getElementById(`step-${currentStep}`).classList.add('hidden');
        document.getElementById(`alt-name-${currentStep}`).classList.add('hidden');

        currentStep = next;

        // Tampilkan step baru
        document.getElementById(`step-${currentStep}`).classList.remove('hidden');
        document.getElementById(`alt-name-${currentStep}`).classList.remove('hidden');

        updateNav();
        updateStepFilled();
    }

    function updateNav() {
        const btnPrev = document.getElementById('btn-prev');
        const btnNext = document.getElementById('btn-next');

        // Prev
        btnPrev.disabled = currentStep === 0;

        // Next: di step terakhir, sembunyikan next (user tinggal klik simpan)
        if (currentStep === TOTAL_STEPS - 1) {
            btnNext.textContent = '';
            btnNext.innerHTML   = `
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                </svg>
                Selesai`;
            btnNext.onclick = null;
            btnNext.disabled = true; // aktifkan hanya jika step terakhir lengkap
            const altId  = altIds[currentStep];
            const filled = filledMap[altId]?.size ?? 0;
            btnNext.disabled = filled < TOTAL_CRIT;
        } else {
            btnNext.innerHTML = `Selanjutnya
                <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                </svg>`;
            btnNext.onclick = () => navigate(1);
            btnNext.disabled = false;
        }

        // Label
        document.getElementById('current-label').textContent = currentStep + 1;
        document.getElementById('current-num').textContent   = currentStep + 1;

        // Dots
        for (let i = 0; i < TOTAL_STEPS; i++) {
            const dot = document.getElementById(`dot-${i}`);
            dot.className = 'h-2 rounded-full transition-all duration-300 ';
            if (i < currentStep) {
                dot.className += 'bg-green-400 flex-1';      // sudah lewat
            } else if (i === currentStep) {
                dot.className += 'bg-blue-600 flex-[2]';     // aktif
            } else {
                dot.className += 'bg-gray-200 flex-1';       // belum
            }
        }
    }

    // ── Update info pengisian per step ────────────────────────────────────────

    function updateStepFilled() {
        const altId  = altIds[currentStep];
        const filled = filledMap[altId]?.size ?? 0;
        document.getElementById('step-filled-label').textContent =
            `${filled}/${TOTAL_CRIT} kriteria diisi`;

        // Update fill bar berdasarkan step aktif
        const pct = TOTAL_CRIT > 0 ? (filled / TOTAL_CRIT * 100) : 0;
        document.getElementById('fill-bar').style.width = pct + '%';
    }

    function updateTotalFilled() {
        let total = 0;
        for (const altId in filledMap) {
            total += filledMap[altId].size;
        }
        document.getElementById('total-filled').textContent = total;

        // Aktifkan tombol simpan hanya jika semua slot terisi
        document.getElementById('btn-simpan').disabled = total < TOTAL_SLOTS;
    }

    // ── Slider change handler ─────────────────────────────────────────────────

    function onSliderChange(slider) {
        const altId  = parseInt(slider.dataset.alt);
        const critId = parseInt(slider.dataset.crit);
        const val    = parseInt(slider.value);

        // Update tampilan nilai
        document.getElementById(`display-${altId}-${critId}`).textContent = val;
        document.getElementById(`decimal-${altId}-${critId}`).textContent  = (val / 10).toFixed(1);

        // Simpan ke hidden input (konversi 1–10 → 0.1–1.0)
        document.getElementById(`hidden-${altId}-${critId}`).value = (val / 10).toFixed(4);

        // Tandai sel terisi
        if (!filledMap[altId]) filledMap[altId] = new Set();
        filledMap[altId].add(critId);

        updateStepFilled();
        updateTotalFilled();

        // Cek apakah step terakhir dan semua terisi → aktifkan "Selesai"
        if (currentStep === TOTAL_STEPS - 1) {
            const filled = filledMap[altIds[currentStep]]?.size ?? 0;
            document.getElementById('btn-next').disabled = filled < TOTAL_CRIT;
        }
    }

    // ── Init ──────────────────────────────────────────────────────────────────

    document.addEventListener('DOMContentLoaded', () => {
        // Inisialisasi display dari nilai tersimpan
        document.querySelectorAll('.slider-input').forEach(slider => {
            const altId  = parseInt(slider.dataset.alt);
            const critId = parseInt(slider.dataset.crit);
            const val    = parseInt(slider.value);

            if (val >= 1) {
                const hiddenInput = document.getElementById(`hidden-${altId}-${critId}`);

                // Jika hidden input belum ada nilainya (belum pernah disimpan),
                // set dari slider default (nilai 1)
                if (!hiddenInput.value) {
                    // Jangan auto-fill — biarkan user yang pilih agar tidak ada bias
                    slider.value = 1;
                } else {
                    // Sudah tersimpan — tampilkan nilai tersimpan
                    document.getElementById(`display-${altId}-${critId}`).textContent = val;
                    document.getElementById(`decimal-${altId}-${critId}`).textContent  = (val / 10).toFixed(1);
                }
            }
        });

        updateNav();
        updateStepFilled();
        updateTotalFilled();
    });
</script>

<style>
    input[type=range] {
        -webkit-appearance: none;
        background: #e5e7eb;
        border-radius: 9999px;
        height: 6px;
        outline: none;
    }
    input[type=range]::-webkit-slider-thumb {
        -webkit-appearance: none;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: var(--slider-color, #2563eb);
        cursor: pointer;
        border: 2px solid white;
        box-shadow: 0 1px 4px rgba(0,0,0,0.2);
    }
    input[type=range]::-moz-range-thumb {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: var(--slider-color, #2563eb);
        cursor: pointer;
        border: 2px solid white;
    }
</style>
@endpush

@endsection
